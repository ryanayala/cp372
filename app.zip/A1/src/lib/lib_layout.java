package lib;

import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JTextField;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.Color;


public class lib_layout extends JFrame {
    public static final int WIDTH = 1280;
    public static final int HEIGHT = 1600;
    private JTextField textbox;
    private JTextField ip_address;
    private JTextField port_num;
    
    private JTextField isbn;
    private JTextField title;
    private JTextField author;
    private JTextField publisher;
    private JTextField year;
    

 
    
    public lib_layout(){
    	
        super();
        setSize(WIDTH,HEIGHT);

        setTitle("Lib");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setLayout(new BorderLayout());
        
        JPanel textpannel = new JPanel();
        textpannel.setLayout(new GridLayout(1,1));
        
        JPanel button_pannel = new JPanel();
        button_pannel.setLayout(new GridLayout(11,1));
        
        JPanel big_pannel = new JPanel();
        big_pannel.setLayout(new BorderLayout() );
    
        JPanel power_pannel = new JPanel();
        power_pannel.setLayout(new GridLayout(2,2));
        
        JPanel small_pannel = new JPanel();
        small_pannel.setLayout(new BorderLayout());
        
        JPanel search_pannel =new JPanel();
        search_pannel.setLayout(new FlowLayout());
        
        JPanel center_pannel = new JPanel();
        center_pannel.setLayout(new FlowLayout());
        
      
        add(textpannel,BorderLayout.EAST);
        add(big_pannel,BorderLayout.WEST);
        add(small_pannel,BorderLayout.NORTH);
        add(center_pannel,BorderLayout.CENTER);
        
        small_pannel.add(power_pannel,BorderLayout.WEST);
        
        center_pannel.add(search_pannel,BorderLayout.EAST);
  
        big_pannel.add(button_pannel,BorderLayout.SOUTH);
        JButton search_button = new JButton("Search");
        JButton upload_button = new JButton("Upload");
        JButton delete_button = new JButton("Delete");
        JButton edit_button = new JButton("Edit");
        
        search_button.setBackground(Color.ORANGE);
        upload_button.setBackground(Color.BLUE);
        delete_button.setBackground(Color.GREEN);
        edit_button.setBackground(Color.RED);
        
        
        button_pannel.add(search_button);
        button_pannel.add(upload_button);
        button_pannel.add(delete_button);
        button_pannel.add(edit_button);
      
        textbox = new JTextField(50);
        textbox.setBackground(Color.WHITE);
        textpannel.add(textbox);
        
        JButton connect_button = new JButton("Connect");
        ip_address =new JTextField(10);
        ip_address.setBackground(Color.WHITE);
        
        port_num = new JTextField(10);
        port_num.setBackground(Color.WHITE);
        
        power_pannel.add(connect_button);
        power_pannel.add(ip_address);
        power_pannel.add(port_num);
        
        isbn = new JTextField(13);
        isbn.setBackground(Color.WHITE);
        
        title = new JTextField(20);
        title.setBackground(Color.WHITE);
        
        author = new JTextField(20);
        author.setBackground(Color.WHITE);
        
        publisher = new JTextField(20);
        publisher.setBackground(Color.WHITE);
        
        year = new JTextField(4);
        year.setBackground(Color.WHITE);
        
        search_pannel.add(isbn);
        search_pannel.add(title);
        search_pannel.add(author);
        search_pannel.add(publisher);
        search_pannel.add(year);

        


    }
}

